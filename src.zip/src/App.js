import React, { useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './config/firebase';
import { useAppointments } from './hooks/useAppointments';
import { appointmentService } from './services/appointmentService';
import ChatBookingForm from './components/ChatBookingForm';
import LoginForm from './components/LoginForm';
import AdminPanel from './components/AdminPanel';
import { Shield } from 'lucide-react';
import './index.css';

function App() {
  // --- Estados da Aplicação ---
  const [currentView, setCurrentView] = useState('booking');
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [editingAppointment, setEditingAppointment] = useState(null);
  const [professionals, setProfessionals] = useState([]);
  const [settings, setSettings] = useState(null);
  const [resetTrigger, setResetTrigger] = useState(0);
  
  // O estado da 'key' não é mais necessário com esta abordagem
  // const [chatKey, setChatKey] = useState(Date.now());

  // --- Hooks Customizados ---
  const {
    appointments, // A lista de agendamentos já está aqui, pronta para ser passada.
    loading,
    autoApprove,
    toggleAutoApprove,
    error,
    fetchAppointments,
    createAppointment,
    updateAppointmentStatus,
    updateAppointment
  } = useAppointments();

  // --- Funções de Busca de Dados ---
  const fetchProfessionals = useCallback(async () => {
    try {
      const profsData = await appointmentService.getAllProfessionals();
      setProfessionals(profsData);
    } catch (error) {
      console.error('Erro ao carregar profissionais:', error);
    }
  }, []);

  const fetchSettings = useCallback(async () => {
    try {
      const settingsData = await appointmentService.getSettings();
      setSettings(settingsData);
    } catch (error) {
      console.error("Falha ao carregar as configurações globais.", error);
    }
  }, []);

  // --- Efeitos ---
  useEffect(() => {
    fetchProfessionals();
    fetchSettings();

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);

      if (currentUser) {
        setCurrentView('admin');
      } else {
        setCurrentView('booking');
        setEditingAppointment(null);
        setResetTrigger((prev) => prev + 1);
      }
    });

    return () => unsubscribe();
  }, [fetchProfessionals, fetchSettings]);


  // --- Handlers de Eventos ---
  const handleBookingSubmit = async (formData) => {
    try {
      let result;
      if (editingAppointment) {
        result = await updateAppointment(editingAppointment.id, formData);
        if (result.success) {
          setEditingAppointment(null);
          setCurrentView('booking');
        }
      } else {
        result = await createAppointment(formData);
      }

      // A lógica da 'key' foi removida. A re-renderização com os novos dados
      // acontecerá naturalmente porque a prop 'appointments' vai mudar.
      return result;

    } catch (err) {
      console.error('Erro ao processar agendamento:', err);
      return {
        success: false,
        error: 'Erro ao processar agendamento. Tente novamente.'
      };
    }
  };

  const handleLoginSuccess = () => setCurrentView('admin');

  const handleEditAppointment = (appointment) => {
    setEditingAppointment(appointment);
    setCurrentView('booking');
  };

  const handleBackToBooking = () => {
    setEditingAppointment(null);
    setCurrentView('booking');
  };

  // --- Renderização ---
  if (authLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    if (currentView === 'login') {
      return <LoginForm onSuccess={handleLoginSuccess} onBack={handleBackToBooking} />;
    }

    if (currentView === 'admin' && user) {
      return (
        <AdminPanel
          appointments={appointments}
          loading={loading}
          autoApprove={autoApprove}
          onToggleAutoApprove={toggleAutoApprove}
          onUpdateStatus={updateAppointmentStatus}
          onEditAppointment={handleEditAppointment}
          onRefresh={fetchAppointments}
          professionals={professionals}
          onProfessionalChange={fetchProfessionals}
          onSettingsUpdate={fetchSettings}
        />
      );
    }

    return (
      <ChatBookingForm
        // A prop 'key' foi removida
        onSubmit={handleBookingSubmit}
        loading={loading}
        editingAppointment={editingAppointment}
        professionals={professionals}
        resetTrigger={resetTrigger}
        user={user}
        currentView={currentView}
        setCurrentView={setCurrentView}
        workingHours={settings?.workingHours || {}}
        // A prop 'appointments' é passada aqui, garantindo que o chat sempre tenha os dados mais recentes
        appointments={appointments}
      />
    );
  };

  return (
    <>
      {currentView !== 'admin' && (
        <div className="absolute top-4 right-4 z-50 hidden md:block">
          <button
            onClick={() => setCurrentView(user ? 'admin' : 'login')}
            className="flex items-center gap-2 bg-gray-700 text-white px-4 py-2 rounded-full hover:bg-gray-800 transition-colors shadow-lg"
            aria-label="Acessar painel administrativo"
          >
            <Shield className="h-5 w-5" />
            <span className="text-sm font-medium">
              {user ? 'Admin' : 'Login'}
            </span>
          </button>
        </div>
      )}

      {renderContent()}

      {error && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 max-w-md p-4 bg-red-100 text-red-700 rounded-md text-center shadow-lg z-50">
          <p><strong>Erro:</strong> {error}</p>
        </div>
      )}
    </>
  );
}

export default App;
