import React, { useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';

// 1. Receba a nova prop 'workingHours'
const DateSelector = ({ onDateSelect, selectedDate, workingHours }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  // Mapeia o getDay() do JS (Dom=0, Seg=1...) para as chaves do seu objeto de configuração
  const dayKeys = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'];

  // 2. Nova função para verificar se o dia está ativo nas configurações
  const isWorkingDay = (date) => {
    // Se as configurações não carregaram, desabilita tudo por segurança.
    if (!date || !workingHours) {
      return false;
    }
    const dayOfWeek = date.getDay(); // Ex: 1 para Segunda-feira
    const dayKey = dayKeys[dayOfWeek]; // Ex: 'seg'
    
    // Retorna true se, por exemplo, 'workingHours.seg.active' for true
    return workingHours[dayKey]?.active || false;
  };

  // Formata uma data para o formato 'YYYY-MM-DD'
  const formatDataForForm = (date) => {
    if (!date) return '';
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Gera os dias visíveis no calendário para o mês atual
  const getDaysInMonth = (year, month) => {
    const date = new Date(year, month, 1);
    const days = [];
    const firstDayOfWeek = date.getDay();

    for (let i = 0; i < firstDayOfWeek; i++) {
      days.push(null);
    }

    while (date.getMonth() === month) {
      days.push(new Date(date));
      date.setDate(date.getDate() + 1);
    }
    return days;
  };

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const calendarDays = getDaysInMonth(year, month);

  const handlePrevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const handleNextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const handleDateInput = (e) => {
    const dateValue = e.target.value;
    if (dateValue) {
      onDateSelect(dateValue);
      const [y, m, d] = dateValue.split('-').map(Number);
      setCurrentDate(new Date(y, m - 1, d));
    }
  };

  const isToday = (date) => {
    if (!date) return false;
    return date.toDateString() === new Date().toDateString();
  };

  const isPast = (date) => {
    if (!date) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  return (
    <div className="w-full py-2 bg-white rounded-lg">
      {/* Cabeçalho com Navegação */}
      <div className="flex items-center justify-between px-2 mb-3">
        <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-gray-100">
          <ChevronLeft className="h-5 w-5 text-gray-600" />
        </button>
        <h3 className="text-sm font-semibold text-gray-800 capitalize">
          {new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(currentDate)}
        </h3>
        <div className="flex items-center gap-2">
          <label className="relative cursor-pointer p-2 rounded-full hover:bg-gray-100">
            <Calendar className="h-5 w-5 text-gray-600" />
            <input
              type="date"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handleDateInput}
              min={formatDataForForm(new Date())}
            />
          </label>
          <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-gray-100">
            <ChevronRight className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Grid do Calendário */}
      <div className="grid grid-cols-7 gap-1 px-2 text-center text-xs">
        {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((day, i) => (
          <div key={i} className="font-medium text-gray-500">{day}</div>
        ))}
        {calendarDays.map((date, index) => {
          if (!date) {
            return <div key={`empty-${index}`} className="h-9 w-9"></div>;
          }

          const formattedDate = formatDataForForm(date);
          const isSelected = formattedDate === selectedDate;
          
          // 3. Lógica de desabilitação atualizada
          const isPastDate = isPast(date);
          const isDayOff = !isWorkingDay(date); // A MÁGICA ACONTECE AQUI!
          const isDisabled = isPastDate || isDayOff;

          return (
            <button
              key={index}
              onClick={() => !isDisabled && onDateSelect(formattedDate)}
              disabled={isDisabled}
              className={`
                h-9 w-9 rounded-full transition-colors duration-200 flex items-center justify-center
                ${isDisabled 
                  ? 'text-gray-300 cursor-not-allowed line-through' // Estilo para dias desabilitados
                  : 'hover:bg-gray-100'
                }
                ${isSelected 
                  ? 'bg-gray-900 text-white hover:bg-gray-800' 
                  : 'bg-transparent'
                }
                ${isToday(date) && !isSelected && !isDisabled ? 'border border-blue-500' : ''}
              `}
            >
              {date.getDate()}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default DateSelector;
